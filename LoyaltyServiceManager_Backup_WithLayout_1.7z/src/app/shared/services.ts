export class Services{
    ServiceName : string;
    ServiceStatus : string;
    MachineName : string;
    DisplayName : string;
    StatusToBeUpdated : number;
    CanPauseAndContinue : boolean;
    CanShutdown : boolean;
    CanStop : boolean;
    IsWebService : boolean;
}
import { Component, OnInit } from '@angular/core';
import { TdDataTableService, TdDataTableSortingOrder, ITdDataTableSortChangeEvent, ITdDataTableColumn } from '@covalent/core/data-table';
import { IPageChangeEvent } from '@covalent/core/paging';
import { Observable, of } from 'rxjs';
import { Http, Headers, RequestMethod, Response, RequestOptions } from '@angular/http';
import { Services } from '../shared/services';
import { ServiceResponse } from '../shared/Response';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { MatRadioModule } from '@angular/material/radio';
import { FileUtil } from '../shared/file.util';
import { debug } from 'util';
const DECIMAL_FORMAT: (v: any) => any = (v: number) => v.toFixed(2);
@Component({
  selector: 'app-test-datatable',
  templateUrl: './test-datatable.component.html',
  styleUrls: ['./test-datatable.component.scss']
})
export class TestDatatableComponent implements OnInit {
  columns: ITdDataTableColumn[] = [
    { name: 'ServiceName', label: 'Service Name', width: 250 },
    { name: 'ServiceStatus', label: 'Service Status', width: 150 },
    { name: 'MachineName', label: 'Machine Name', hidden: false, width: 200 },
    { name: 'DisplayName', label: 'Detailed Name', width: 350 },
    { name: 'IsWebService', label: 'IsWebService', width: 150 },
    { name: 'StatusToBeUpdated', label: 'Start Service', width: 150 },
    { name: 'StatusToBeUpdated1', label: 'Stop Service', width: 150 }
    // {name: 'StatusToBeUpdated2', label: 'Pause Service',width:160},
    // {name: 'StatusToBeUpdated3', label: 'Restart Service',width:160},
  ];
  ServiceOption: string = "false";
  data: any[];
  apiUrl: string = "http://localhost/Service_Manager_API/api/service";
  now: Date;
  filteredData: any[];
  filteredTotal: number;

  searchTerm: string = '';
  fromRow: number = 1;
  currentPage: number = 1;
  pageSize: number = 50;
  sortBy: string = 'ServiceName';
  selectedRows: Services[] = [];
  _response: ServiceResponse[] = [];
  _defaultResponse: ServiceResponse = new ServiceResponse();

  sortOrder: TdDataTableSortingOrder = TdDataTableSortingOrder.Descending;
  headers: Headers
  options: RequestOptions
  MachineName: string = '';

  //keep the flag true if csv contains header else not, this falg will help in validations.
  static isHeaderPresentFlag = true;

  //keep the flag true if you want to validate each records length to match with header length, false otherwise.
  static validateHeaderAndRecordLengthFlag = true;

  //keep the flag true if you want file with only .csv extensions should be read, false otherwise.
  static valildateFileExtenstionFlag = true;

  static tokenDelimeter = ",";

  // @ViewChild('fileImportInput')
  fileImportInput: any;

  csvRecords: string = '';
  constructor(private _dataTableService: TdDataTableService, private _http: Http, private _httpCLient: HttpClient, private _fileUtil: FileUtil) { }

  ngOnInit(): void {
    this._defaultResponse.ErrorMessage = "";
    this._response[0] = this._defaultResponse;
    console.log("Service Called")
   // this.getServices();
  }
  getServices() {

    this.now = new Date();
    this.data = [];
    console.log(this.now)
    if (this.ServiceOption == "true" && this.MachineName == '') {
      alert('Server Name is Mandatory');
    }
    else if (this.ServiceOption == "true" && this.MachineName != '') {
      this._http.get(this.apiUrl + "?MachineName=" + this.MachineName)
        .subscribe(response => {
          debugger;
          this.data = response.json()
          this.now = new Date();
          //this.filter();
          console.log(this.data);
        });
    }
    else {
      this._http.get(this.apiUrl)
        .subscribe(response => {
          debugger
          this.data = response.json();
          //this.filter();
          this.now = new Date();
          console.log(this.data);
        });
    }
  }
  // Update()
  // {}
  Update(Status: number) {
    // alert(this.apiUrl)
    this.selectedRows[0].StatusToBeUpdated = Status;
    this.headers = new Headers({ 'Content-Type': 'application/json' });
    var requestOptions = new RequestOptions({ method: RequestMethod.Put, headers: this.headers });
    var body = JSON.stringify(this.selectedRows);
    console.log(this.apiUrl + " - " + body);
    return this._http.put(this.apiUrl, body, requestOptions)
      .subscribe(response => {
        this._response = response.json()
        this.getServices();
      });
  }
  uploadServers() {
    this.headers = new Headers({ 'Content-Type': 'application/json' });
    var requestOptions = new RequestOptions({ method: RequestMethod.Put, headers: this.headers });
    var body = '';
    var URL = this.apiUrl + '?CSVData=' + this.csvRecords;

    return this._http.put(URL, body, requestOptions).subscribe(response => {
      body = response.statusText;
      this.getServices();
      alert('Uploaded Successfully');
    });
  }
  private extractData(res: Response) {
    let body = res.json();
    return body || {};
  }
  sort(sortEvent: ITdDataTableSortChangeEvent): void {
    this.sortBy = sortEvent.name;
    this.sortOrder = sortEvent.order;
    this.filter();
  }

  search(searchTerm: string): void {
    this.searchTerm = searchTerm;
    this.filter();
  }

  page(pagingEvent: IPageChangeEvent): void {
    this.fromRow = pagingEvent.fromRow;
    this.currentPage = pagingEvent.page;
    this.pageSize = pagingEvent.pageSize;
    this.filter();
  }

  showAlert(event: any): void {
    let row: any = event.row;
    // .. do something with event.row
  }

  filter(): void {
    let newData: any[] = this.data;
    let excludedColumns: string[] = this.columns
      .filter((column: ITdDataTableColumn) => {
        return ((column.filter === undefined && column.hidden === true) ||
          (column.filter !== undefined && column.filter === false));
      }).map((column: ITdDataTableColumn) => {
        return column.name;
      });
    newData = this._dataTableService.filterData(newData, this.searchTerm, true, excludedColumns);
    this.filteredTotal = newData.length;
    newData = this._dataTableService.sortData(newData, this.sortBy, this.sortOrder);
    newData = this._dataTableService.pageData(newData, this.fromRow, this.currentPage * this.pageSize);
    this.data = newData;
  }

  // METHOD CALLED WHEN CSV FILE IS IMPORTED
  fileChangeListener($event): void {

    var text = [];
    var files = $event.srcElement.files;

    if (TestDatatableComponent.validateHeaderAndRecordLengthFlag) {
      if (!this._fileUtil.isCSVFile(files[0])) {
        alert("Please import valid .csv file.");
        this.fileReset();
      }
    }

    var input = $event.target;
    var reader = new FileReader();
    reader.readAsText(input.files[0]);
    reader.onloadend = function () {
      alert('Read Ended')
    }

    reader.onloadend = (data: any) => {

      let csvData = data.target.result;
      let csvRecordsArray = csvData.split(/\r\n|\n/);

      var headerLength = -1;
      if (TestDatatableComponent.isHeaderPresentFlag) {
        let headersRow = this._fileUtil.getHeaderArray(csvRecordsArray, TestDatatableComponent.tokenDelimeter);
        headerLength = headersRow.length;
      }

      this.csvRecords = this._fileUtil.getDataRecordsArrayFromCSVFile(csvRecordsArray,
        headerLength, TestDatatableComponent.validateHeaderAndRecordLengthFlag, TestDatatableComponent.tokenDelimeter);
      console.log(this.csvRecords)
      if (this.csvRecords == null) {
        this.fileReset();
      }
    }

    reader.onerror = function () {
      alert('Unable to read ' + input.files[0]);
    };
  };

  fileReset() {
    this.fileImportInput.nativeElement.value = "";
    this.csvRecords = '';
  }

}
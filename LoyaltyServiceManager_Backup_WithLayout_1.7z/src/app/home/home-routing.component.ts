// import { RouterModule, Routes } from '@angular/router';
// import {TestDatatableComponent} from '../test-datatable/test-datatable.component';
// import { HomeComponent }     from '../home/home.component';
// import { EnvironmentDetailsComponent }     from '../environment-details/environment-details.component';

// export const routes: Routes = [
//         {
//             path: 'home', component: HomeComponent, children: [
//             { path: 'services', component: TestDatatableComponent },
//             { path: 'Applications', component: EnvironmentDetailsComponent,}
//         ]
//     }
// ];
// // export const vendorRouterModule = RouterModule.forRoot(routes);
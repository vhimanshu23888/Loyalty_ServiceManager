export class CommonConstants {
    public static ApiURL:string ="http://localhost/Service_Manager_API/api/service/"
    // public static ApiURL:string ="http://172.28.70.23:3800/api/service/"
    
}